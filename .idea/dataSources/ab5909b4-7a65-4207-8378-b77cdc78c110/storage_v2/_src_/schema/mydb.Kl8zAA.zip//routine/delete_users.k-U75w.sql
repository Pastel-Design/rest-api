create
    definer = root@localhost procedure delete_users()
BEGIN
	 DELETE FROM rating;
	 DELETE FROM comment;
     DELETE FROM user_has_chat_session;
	 DELETE FROM message;
     DELETE FROM chat_session;
     DELETE FROM product_has_order; 
     DELETE FROM user_order;
     DELETE FROM invoice_adress;
     DELETE FROM shipping_adress;
     DELETE FROM product_has_shopping_cart;
     DELETE FROM shopping_cart;
END;

