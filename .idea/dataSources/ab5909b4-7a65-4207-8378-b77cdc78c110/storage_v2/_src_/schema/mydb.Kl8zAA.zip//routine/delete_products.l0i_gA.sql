create
    definer = root@localhost procedure delete_products()
BEGIN
	 DELETE FROM rating;
	 DELETE FROM comment;
     DELETE FROM product_has_order; 
     DELETE FROM user_order;
     DELETE FROM product_has_shopping_cart;
     DELETE FROM shopping_cart;
     DELETE FROM parameter_has_product;
     DELETE FROM image_has_product;
     DELETE FROM image;
     DELETE FROM price;
     DELETE FROM storage;
     DELETE FROM discount;
     DELETE FROM product;
END;

