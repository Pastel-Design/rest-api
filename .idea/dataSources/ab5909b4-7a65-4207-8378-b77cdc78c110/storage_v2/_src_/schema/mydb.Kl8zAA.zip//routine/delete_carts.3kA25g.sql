create
    definer = root@localhost procedure delete_carts()
BEGIN
	 DELETE FROM product_has_shopping_cart;
     DELETE FROM shopping_cart;
END;

