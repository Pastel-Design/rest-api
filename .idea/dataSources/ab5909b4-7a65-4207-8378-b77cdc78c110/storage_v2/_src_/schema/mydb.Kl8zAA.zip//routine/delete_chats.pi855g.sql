create
    definer = root@localhost procedure delete_chats()
BEGIN
	 DELETE FROM user_has_chat_session;
     DELETE FROM message;
     DELETE FROM chat_session;
END;

