create
    definer = root@localhost procedure delete_orders()
BEGIN
	 DELETE FROM product_has_order;
     DELETE FROM user_order;
END;

