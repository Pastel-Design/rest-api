create
    definer = root@localhost procedure delete_subcategories()
BEGIN
	 DELETE FROM category WHERE main_category = 0;
END;

